#!/usr/bin/env bash
# Cambia el autor de TODOS los commits (el repo se generó con un correo de marcador).
# Uso:  ./reescribir_autor.sh "Tu Nombre" "tu_correo@ejemplo.com"   (ejecutar DENTRO de cadenafria-uraba/, antes de publicar)
set -euo pipefail
NAME="$1"; MAIL="$2"
git filter-branch -f --env-filter "
export GIT_AUTHOR_NAME='$NAME'; export GIT_COMMITTER_NAME='$NAME'
export GIT_AUTHOR_EMAIL='$MAIL'; export GIT_COMMITTER_EMAIL='$MAIL'
" --tag-name-filter cat -- --all
rm -rf .git/refs/original && git reflog expire --expire=now --all && git gc -q --prune=now
echo "Autor actualizado. Revise con: git log --format='%h %an <%ae> %s'"
